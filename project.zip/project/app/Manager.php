<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Manager extends Model
{
    protected $table='transaction';
    protected $primarykey='id';
    public $timestamps= false;
}
