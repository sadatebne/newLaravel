<!DOCTYPE html>
<html>
<head>
	<title>Admin Home</title>
</head>
<body>
	<h1>Admin Home</h1>
	<a href="<?php echo e(route('admin.home')); ?>"> Home</a> | 
	<a href="<?php echo e(route('admin.personalinfo')); ?>"> Personal Info</a> |
	<a href="<?php echo e(route('admin.createemployee')); ?>"> Register New | 
	<a href="<?php echo e(route('admin.employeelist')); ?>"> View All Employee | 
	<a href="<?php echo e(route('admin.users')); ?>">Search User</a> |
	<a href="/logout"> logout
</body>
</html>
<?php /**PATH S:\Final Full Marge Project\Final_Project-laravel--master\resources\views/admin/home.blade.php ENDPATH**/ ?>