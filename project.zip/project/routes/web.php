<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login',  'loginController@index');
Route::post('/login', 'loginController@verify');

Route::group(['middleware'=>['sess']], function() {

Route::get('/manager/home',     'managerController@index')->name('manager.index');

Route::get('/manager/profile',          'managerController@profile')->name('manager.profile');

Route::get('/manager/profileUpdate',    'managerController@profileView')->name('manager.profileView');
Route::post('/manager/profileUpdate',   'managerController@profileUpdate');


//Employees

Route::get('/manager/empCreate',       'managerController@empCreate')->name('manager.empCreate');
Route::post('/manager/empCreate',      'managerController@empStore');

Route::get('/manager/emplist',         'managerController@emplist')->name('manager.emplist');

Route::get('/manager/empDetails/{id}', 'managerController@empDetails')->name('manager.empDetails');

Route::get('/manager/empEdit/{id}',    'managerController@empEdit')->name('manager.empEdit');
Route::post('/manager/empEdit/{id}',   'managerController@empUpdate');


Route::get('/manager/empDelete/{id}',  'managerController@empDestroyView')->name('manager.empDestroyView');
Route::post('/manager/empDelete/{id}', 'managerController@empDestroy');

Route::get('/empSearch',       'managerController@empSearch');
Route::get('/search',          'managerController@search')->name('search');

Route::get('/manager/empSalary',       'managerController@empSalary')->name('manager.empSalary');

Route::get('/manager/empAddSalaryView/{id}',      'managerController@empAddSalaryView')->name('manager.empAddSalaryView');
Route::post('/manager/empAddSalaryView/{id}',      'managerController@empAddSalary')->name('manager.empAddSalary');


//Customer

Route::get('/manager/custlist',         'managerController@custlist')->name('manager.custlist');

Route::get('/manager/custEdit/{id}',    'managerController@custEdit')->name('manager.custEdit');
Route::post('/manager/custEdit/{id}',   'managerController@custUpdate');

Route::get('/manager/custDetails/{id}', 'managerController@custDetails')->name('manager.custDetails');

});

Route::get('/logout',  'logoutController@index');