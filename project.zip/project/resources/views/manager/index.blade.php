<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>
<h1>Welcome home {{$username}}</h1>
    <a href="{{route('manager.profile')}}">Profile</a> |
	<a href="/manager/empCreate">Create New User</a> |
	<a href="{{route('manager.emplist')}}">View Employee List</a> |
	<a href="{{route('manager.custlist')}}">View Client List</a> |
	<a href="/manager/empSalary">Employee Salary List</a> |
	<a href="/logout">logout</a>

</body>
</html>